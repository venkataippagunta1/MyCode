package com.Venkata.spring.rest.controllers;

import java.util.List;
import java.util.ListIterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import java.util.Date;
import com.Venkata.spring.rest.model.Payments;
import com.Venkata.spring.rest.repos.PaymentRepo;


@RestController
@RequestMapping("/payments")
public class PaymentRestController{
	
	@Autowired
	PaymentRepo repo;
	long currentSeconds = new Date().getTime();
	long secondsIn30Days = 30 * 24 * 60 * 60 * 1000;
	
	@RequestMapping(value="/payments/{userId/}",method = RequestMethod.GET)
	public long getPayments(@PathVariable("userId") String userId){
		Payments payments = repo.findAllById(userId);
		for(Payments payment: payments) {
			if(payments.getPaymentDate().getTime() >(currentSeconds - secondsIn30Days))
				return payments.getId();
		}
		
	}

}
