package com.Venkata.spring.rest.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Venkata.spring.rest.model.Payments;

public interface PaymentRepo extends JpaRepository<Payments, Long> {

	Payments findAllById(String userId);

}
